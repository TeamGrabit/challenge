module.exports ={
    mongoURI:'mongodb+srv://HyunGwang:1234@cluster0.xstvm.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}